package snippet;

public class Snippet {
	public static void main(String[] args) {
		/html/body/form/table/tbody/tr[3]/td[2]/input[1]
	}
}

