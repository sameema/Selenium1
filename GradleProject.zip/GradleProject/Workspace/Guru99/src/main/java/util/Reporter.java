package util;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Reporter {
	
	//Since the 'html' object is shared by all objects we use, declared as static
	public static ExtentHtmlReporter html;
	
	//Since the 'extent' object is shared by all objects we use, declared as static
    public static ExtentReports extent;
    
	//Since the 'test' object is shared by all objects we use, declared as static
    public ExtentTest test;
    
	//Since the values for the below variables taken from the test case and it should be declared as class variables
    public String testcaseName, testDesc, author, category, excelFileName;
    
    
    @BeforeSuite
    //since we need to make the results of the to be ready before run the test, it is used as @BeforSuite
	public void startResult() {
    	
    	//creating blank html file
    	//result.html is the file where we store our results later
		html = new ExtentHtmlReporter("./reports/result.html");
		
		//used to append all the test cases whatever we run in the same file
		html.setAppendExisting(true); 
		
		//used to add multiple logs.ExtentReports is a HTML reporting library for Java, which can be used with Selenium WebDriver.
		extent= new ExtentReports();
		
		//used to add individual log
		extent.attachReporter(html); 
	}
    
    
    @BeforeMethod
    //this method needs to be executed,after each and every test case run to pick the values of Test Case.so we use the annotation @BeforeMethod
    public void startTestCase() {
    	
    	//Extent Test class is used to log test steps onto the generated HTML report. Ex.test case name, description, author, type of test
    	test = extent.createTest(testcaseName, testDesc);
	    test.assignAuthor(author);
	    test.assignCategory(category);
	}
    
	public void reportSteps(String status,String desc) {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(desc);
		} else if (status.equalsIgnoreCase("fail")) {
			test.fail(desc);
		}
	}
	
	
	@AfterSuite
	public void stopResult() {
		//Appends the HTML file with all the ended tests
		 extent.flush();
	}
}





	


