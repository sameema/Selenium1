package guru99;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class VerifyLogin {
	
	public static void main(String[] args) {
		//Get the driver details - path
				System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
				//launch the browser
				ChromeDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.get("http://www.demo.guru99.com/V4/");
				WebElement userName = driver.findElementByXpath("//table/tbody/tr[1]/td[2]/input");
				userName.sendKeys("mngr171064");
				WebElement password = driver.findElementByXpath("//table/tbody/tr[2]/td[2]/input");
				password.sendKeys("uzAjaje");
				driver.findElementByXpath("//table/tbody/tr[3]/td[2]/input[1]").click();

}
}