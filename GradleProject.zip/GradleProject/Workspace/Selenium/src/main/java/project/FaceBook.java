package project;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import wdmethods.SeMethods;

public class FaceBook extends SeMethods
{
	@BeforeClass
	public void setData() {
		testcaseName ="FaceBook";
		testDesc ="Activities in Facebook";
		author ="Sameema";
		category = "Smoke";
	}
	

	@Test
	public void faceBook() 
	{
		startApp("chrome", "https://www.facebook.com/");
		
		WebElement userId = locateElement("xpath", "//div[@class='clearfix loggedout_menubar']//descendant::input[2]");
		type(userId, "sonsy86@gmail.com");
		
		WebElement password = locateElement("xpath", "//div[@class='clearfix loggedout_menubar']//descendant::input[3]");
		type(password, "bishmillah");
		
		WebElement login = locateElement("xpath", "//div[@class='clearfix loggedout_menubar']//descendant::input[4]");
		click(login);
				
		WebElement searchText = locateElement("xpath", "//div[@id='globalContainer']//preceding::input[1]");
		type(searchText, "TestLeaf");
		
		WebElement searchIcon = locateElement("xpath", "//div[@id='globalContainer']//preceding::button");
		click(searchIcon);
		
		WebElement like = locateElement("xpath", "//div[text()='TestLeaf']//following::i[1]");
		String name = like.getText();
		if(name.equals("Like"))
		{
			click(like);
		}
		else if(name.equals("Liked"))
		{
			test.info("It is already liked");
		}



	
	}

	}


