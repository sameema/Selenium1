package project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZoomCar {

	public static void main(String[] args) {
    System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    ChromeDriver driver = new ChromeDriver();
    driver.get("https://www.zoomcar.com/chennai");
    driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.findElementByLinkText("Start your wonderful journey").click();
    driver.findElementByXPath("//div[text()='Popular Pick-up points']/following::div[1]").click();
    driver.findElementByClassName("proceed").click();
    WebElement dateFind = driver.findElementByXPath("//div[@class='day picked full']/following::div[1]");
    String date1 = dateFind.getText();
    //System.out.println(date1);
    dateFind.click();;
    driver.findElementByClassName("proceed").click();
/*    Date date = new Date();
    DateFormat sdf = new SimpleDateFormat("dd");
    String today = sdf.format(date);
    int tomorrow = Integer.parseInt(today)+1;
*/    WebElement dateVerify = driver.findElementByXPath("//div[@class='days']/div");
    String date2 = dateVerify.getText();
    //System.out.println(date2);
    if(date2.equals(date1))
    {
    	System.out.println("Date is correct");
    }
    else
    {
    	System.out.println("The clicked date is wrong");
    }
    driver.findElementByClassName("proceed").click();
    List<WebElement> price = driver.findElementsByXPath("//div[@class='price']");
    List<String> list = new ArrayList<>();
    System.out.println(price.size());
    for(WebElement eachPrice:price) 
    {
    	list.add(eachPrice.getText());
    }
    String max = Collections.max(list);
    String replaceAll = max.replaceAll("\\D", "");
    System.out.println(replaceAll);
    WebElement brand = driver.findElementByXPath("//div[@class='price' and contains(text(),'"+replaceAll+"')]/preceding::h3[1]");
    System.out.println(brand.getText());
    driver.findElementByXPath("//div[@class='price' and contains(text(),'"+replaceAll+"')]/following::button").click();	
    driver.close();
        }

}
