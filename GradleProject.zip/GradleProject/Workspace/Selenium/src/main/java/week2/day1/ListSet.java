package week2.day1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class ListSet {

	public static void main(String[] args) {
		List<Long> ls = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();
		System.out.println("Enter the contact numbers");
		for(int i=0; i<size; i++)
		{
			Long number = scan.nextLong();
			ls.add(number);
		}
for(Long print:ls)
{
	System.out.println(print);
}
Set<Long> set = new HashSet<>();
set.addAll(ls);
System.out.println(set);
System.out.println("The number of duplicates are "+ (ls.size()-set.size()));

scan.close();
	}

}

