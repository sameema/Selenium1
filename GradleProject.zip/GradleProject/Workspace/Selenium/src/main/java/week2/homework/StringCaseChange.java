package week2.homework;

import java.util.Scanner;

public class StringCaseChange {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		String name = scan.next();
		StringBuilder output= new StringBuilder ();

		for(int i=0;i<name.length();i++)
		{

		char c = name.charAt(i);

		if(i%2==0){

		output.append(Character.toLowerCase(c));

		} else {

		output.append(Character.toUpperCase(c));
		}
		}
		System.out.print(output.toString());


		/*String word="";
		for(int i=0; i<name.length(); i++)
		{
			char ch = name.charAt(i);
			if(i%2==0)
			{
				ch=Character.toUpperCase(ch);
				word=word+ch;
			}
			
			
		}
		System.out.println("Required String : "+word);*/
		scan.close();

	}

}
