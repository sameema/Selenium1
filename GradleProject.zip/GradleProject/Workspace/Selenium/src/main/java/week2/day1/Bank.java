package week2.day1;

public class Bank {

	public static void main(String[] args) {
SBINanganallur sbi = new SBINanganallur();
HDFCNanganallur hdfc = new HDFCNanganallur();
sbi.aadharMandatory();
sbi.minimumBalance();
sbi.setPersonalLoan();
hdfc.setHomeLoan();
	}

}
