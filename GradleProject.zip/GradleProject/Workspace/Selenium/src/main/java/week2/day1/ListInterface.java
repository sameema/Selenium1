package week2.day1;

import java.util.ArrayList;
import java.util.List;

public class ListInterface {

	public static void main(String[] args) {
		int count = 1;
		List<String> ls = new ArrayList<>();
		ls.add("Sameema");
		ls.add("Kaja");
		ls.add("Ifrah");
		ls.add("Kursith");
		ls.add("Kaja");
		ls.add("Sameema");
		ls.add("Rishvana");
		ls.add("Sameema");
		  
for(int i =0; i<ls.size(); i++)
{
	String value1 = ls.get(i);
	for(int j=1; j<ls.size(); j++)
	{
				String value2 = ls.get(j);
	if(value1.equals(value2))
	{
		count++;
	}
	}
System.out.println(ls.get(i)+" duplicates come for "+count);

}

	}

}
