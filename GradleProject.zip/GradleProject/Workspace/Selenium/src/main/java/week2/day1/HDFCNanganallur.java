package week2.day1;

public class HDFCNanganallur implements HDFCIndia{
	public void setHomeLoan()
	{
		System.out.println("The home loan percentage is 7");
	}


}
