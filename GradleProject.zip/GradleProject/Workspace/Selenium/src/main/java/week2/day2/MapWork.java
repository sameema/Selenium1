package week2.day2;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class MapWork {

	//frequently asked in interview
	//display the occurance of the characters in a String
	
	public static void main(String[] args) {

Scanner scan = new Scanner(System.in);
System.out.println("Enter the String");
String name = scan.next();
char[] ch = name.toCharArray();
Map<Character,Integer> map = new LinkedHashMap<>();

for(int i =0; i<ch.length; i++)
	//for(char c:ch)
{

		if(map.containsKey(ch[i]))
				{
			//occurance.put(c,occurance.get(c)+1);
			int value = map.get(ch[i]);
			value++;
			map.put(ch[i], value);
				}
		else
		{
			//occurance.put(c,1);
			map.put(ch[i], 1);
		}
}
//System.out.println(occurance);
		for(char key:map.keySet())
		{
			System.out.println(key+"--> "+map.get(key));
		}

scan.close();
	}

}
