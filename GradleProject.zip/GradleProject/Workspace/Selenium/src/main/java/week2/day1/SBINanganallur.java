package week2.day1;

public class SBINanganallur implements SBIIndia{
	public void setPersonalLoan()
	{
		System.out.println("The Personal loan percentage is 11");
	}
	public void aadharMandatory()
	{
		System.out.println("Aadhar is Mandatory");
	}
	public void minimumBalance()
	{
		System.out.println("Minimum balance should be 5000");
	}

}
