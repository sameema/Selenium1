package week2.day1;

public interface HDFCIndia {
public void setHomeLoan();
}
