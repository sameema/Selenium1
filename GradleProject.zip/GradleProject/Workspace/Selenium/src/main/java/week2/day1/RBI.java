package week2.day1;

public interface RBI {
	public void aadharMandatory();
	public void minimumBalance();
	
}
