package week2.day1;

import java.util.ArrayList;
import java.util.Collections;
//import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class ListDuplicates {

	public static void main(String[] args) {
List<String> ls = new ArrayList<>();
Scanner scan = new Scanner(System.in);
System.out.println("Enter the number of employees");
int number = scan.nextInt();
System.out.println("Enter the names");
for(int i=0; i<number; i++)
{
	String employee = scan.next();
	ls.add(employee);
}
Collections.sort(ls);
for(String sort:ls)
{
	System.out.println(sort);
}
Set<String> set = new TreeSet<>();
set.addAll(ls);
System.out.println(set);

scan.close();
	}

}
