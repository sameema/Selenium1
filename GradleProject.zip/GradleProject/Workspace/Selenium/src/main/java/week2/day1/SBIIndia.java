package week2.day1;

public interface SBIIndia extends RBI {
	public void setPersonalLoan();

}
