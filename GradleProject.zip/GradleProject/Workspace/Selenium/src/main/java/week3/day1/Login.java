package week3.day1;


import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Login {

	public static void main(String[] args) {
//Get the driver details - path
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		//launch the browser
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		//load the url
		driver.get("http://leaftaps.com/opentaps");
		//get the username
		WebElement username = driver.findElementById("username");
		username.sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys("Standard Chartered");
		driver.findElementById("createLeadForm_firstName").sendKeys("Anu");
		driver.findElementById("createLeadForm_lastName").sendKeys("Smitha");
		WebElement source = driver.findElementById("createLeadForm_dataSourceId");
		Select se = new Select(source);
		se.selectByVisibleText("Employee");
		WebElement market = driver.findElementById("createLeadForm_marketingCampaignId");
		Select sel = new Select(market);
		sel.selectByValue("CATRQ_CARNDRIVER");
	    WebElement industry = driver.findElementById("createLeadForm_industryEnumId");
	    Select sele = new Select(industry);
	    List<WebElement> allOptions = sele.getOptions();
	    for (WebElement element : allOptions) {
	    	if(element.getText().startsWith("C")) {
	    		System.out.println(element.getText());
	    	}
			
		}
		driver.findElementByName("submitButton").click();
		
	}

}
