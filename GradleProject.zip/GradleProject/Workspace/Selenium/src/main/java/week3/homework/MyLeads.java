package week3.homework;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MyLeads {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("http://leaftaps.com/opentaps");
driver.findElement(By.xpath("//input[@id='username']")).sendKeys("DemoSalesManager");
driver.findElement(By.xpath("//input[@id='password']")).sendKeys("crmsfa");
driver.findElement(By.xpath("//input[@value='Login']")).click();
driver.findElement(By.xpath("//a[@text='CRM/SFA']")).click();
driver.findElement(By.xpath("//a[@text='Create']")).click();
driver.findElement(By.xpath("//input[@name='companyName']")).sendKeys("Standard Chatered");
driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Anu");
driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("Smitha");
driver.findElement(By.xpath("//input[@name='firstNameLocal']")).sendKeys("Anu");
driver.findElement(By.xpath("//input[@name='lastNameLocal']")).sendKeys("Smitha");














	}

}
