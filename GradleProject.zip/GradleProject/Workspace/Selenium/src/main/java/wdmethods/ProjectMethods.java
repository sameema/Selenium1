package wdmethods;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import week6.day2.LearnExcel;

public class ProjectMethods extends SeMethods
{
	@BeforeMethod
	@Parameters({"browser","url","username","password"})
	public void login(String brow, String url, String userName, String password) {
		startApp(brow,url);
		WebElement eleUsername = locateElement("id", "username");
		type(eleUsername, userName);
		WebElement elePassword = locateElement("id", "password");
		type(elePassword, password);
		WebElement eleLogin = locateElement("class", "decorativeSubmit");
		click(eleLogin); 
	}
	
	@DataProvider(name="FetchData")
	public String[][] getData() throws IOException
	{
		return week6.day2.LearnExcel.getExcelData("CreateLead");
	}

	
}
