package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import wdmethods.ProjectMethods;


public class TC002_CreateLead extends ProjectMethods
{
	
	@BeforeClass
	public void setData() {
		testcaseName ="TC001_CreateLead";
		testDesc ="Create a new lead in leaftaps";
		author ="Gayatri";
		category = "Smoke";
		excelFileName = "CreateLead";
	}
	
	
	/*@BeforeMethod(groups="config")
	public void setUp()
	{
		login();
	}*/
	
	@AfterMethod
	public void close()
	{
		closeBrowser();
	}

@Test(dataProvider="FetchData")

//@Test(groups="test.reg")
public void createLead(String cmpnyName, String firstName, String lastName)
{
	WebElement eleCrmSfa = locateElement("linktext", "CRM/SFA");
	click(eleCrmSfa); 
	
	WebElement eleCreateLead = locateElement("linktext", "Create Lead");
	click(eleCreateLead); 
	
	WebElement eleCompanyName = locateElement("id", "createLeadForm_companyName");
	type(eleCompanyName, cmpnyName);
	
	WebElement eleFirstName = locateElement("id", "createLeadForm_firstName");
	type(eleFirstName, firstName);
	
	WebElement eleLastName = locateElement("id", "createLeadForm_lastName");
	type(eleLastName, lastName);
	
	WebElement eleSourceName = locateElement("id", "createLeadForm_dataSourceId");
	selectDropDownUsingText(eleSourceName,"Employee","visible");
	
	WebElement eleCampaign = locateElement("id", "createLeadForm_marketingCampaignId");
	selectDropDownUsingText(eleCampaign,"Automobile","visible");
	
	WebElement eleFirstNameLocal = locateElement("id", "createLeadForm_firstNameLocal");
	type(eleFirstNameLocal, "Sameema");
	
	WebElement eleLastNameLocal = locateElement("id", "createLeadForm_lastNameLocal");
	type(eleLastNameLocal, "Rani");
	
	WebElement elePersonalTitle = locateElement("createLeadForm_personalTitle");
	type(elePersonalTitle, "Mrs");
	
/*	WebElement eleBirthdayDate = locateElement("createLeadForm_birthDate-button");
	selectDropDownUsingText(eleBirthdayDate,"29/09/86","visible");
*/	
	WebElement eleGeneralTitle = locateElement("createLeadForm_generalProfTitle");
	type(eleGeneralTitle, "SSE");
	
	WebElement eleDepartmentName = locateElement("createLeadForm_departmentName");
	type(eleDepartmentName, "COOP");
	
	WebElement eleAnnualIncome = locateElement("createLeadForm_annualRevenue");
	type(eleAnnualIncome, "10,00,000");

	WebElement eleCurrency = locateElement("id", "createLeadForm_currencyUomId");
	selectDropDownUsingText(eleCurrency,"INR - Indian Rupee","visible");
	
	WebElement eleIndustry = locateElement("id", "createLeadForm_industryEnumId");
	selectDropDownUsingText(eleIndustry,"Computer Software","visible");
	
	WebElement eleTotalEmployees = locateElement("createLeadForm_numberEmployees");
	type(eleTotalEmployees, "100");
	
	WebElement eleOwnership = locateElement("id", "createLeadForm_ownershipEnumId");
	selectDropDownUsingText(eleOwnership,"Corporation","visible");
	
	WebElement eleSicCode = locateElement("createLeadForm_sicCode");
	type(eleSicCode, "333");
	
	WebElement eleTickerSymbol = locateElement("createLeadForm_tickerSymbol");
	type(eleTickerSymbol, "###");
	
	WebElement eleDescription = locateElement("createLeadForm_description");
	type(eleDescription, "Hi How Are You");
	
	WebElement eleImportantNote = locateElement("createLeadForm_importantNote");
	type(eleImportantNote, "Nothing");
	
	WebElement eleCountryCode = locateElement("createLeadForm_primaryPhoneCountryCode");
	type(eleCountryCode, "350");
	
	WebElement eleContactnumber = locateElement("createLeadForm_primaryPhoneNumber");
	type(eleContactnumber, "9994572095");
	
	WebElement eleAreaCode = locateElement("createLeadForm_primaryPhoneAreaCode");
	type(eleAreaCode, "044");
	
	WebElement elePerson = locateElement("createLeadForm_primaryPhoneAskForName");
	type(elePerson, "Manager");

	WebElement eleExtensionCode = locateElement("createLeadForm_primaryPhoneExtension");
	type(eleExtensionCode, "+91");

	WebElement eleWebUrl = locateElement("createLeadForm_primaryWebUrl");
	type(eleWebUrl, "www.leaftaps.com");

	WebElement eleEmail = locateElement("createLeadForm_primaryEmail");
	type(eleEmail, "sameemrajkapoor@gmail.com");

	WebElement eleToName = locateElement("createLeadForm_generalToName");
	type(eleToName, "Ifrah");

	WebElement eleAttentionName = locateElement("createLeadForm_generalAttnName");
	type(eleAttentionName, "Kaja");

	WebElement eleAddressLine1 = locateElement("createLeadForm_generalAddress1");
	type(eleAddressLine1, "No., 2, Kalki Nagar");

	WebElement eleAddressLine2 = locateElement("createLeadForm_generalAddress2");
	type(eleAddressLine2, "Velachery");

	WebElement eleCity = locateElement("createLeadForm_generalCity");
	type(eleCity, "Chennai");
	
	WebElement eleCountry = locateElement("id", "createLeadForm_generalCountryGeoId");
	selectDropDownUsingText(eleCountry,"India","visible");
	
	WebElement eleState = locateElement("id", "createLeadForm_generalStateProvinceGeoId");
	selectDropDownUsingText(eleState,"TAMILNADU","visible");

	WebElement elePostalCode = locateElement("createLeadForm_generalPostalCode");
	type(elePostalCode, "600042");
	
	WebElement eleZipCode = locateElement("createLeadForm_generalPostalCodeExt");
	type(eleZipCode, "044");
	
	WebElement eleCreateLeadButton = locateElement("xpath", "//input[@value='Create Lead']");
	click(eleCreateLeadButton);    


}

}
