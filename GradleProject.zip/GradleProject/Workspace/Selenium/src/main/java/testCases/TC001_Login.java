package testCases;

import org.testng.annotations.Test;

import wdmethods.ProjectMethods;

public class TC001_Login extends ProjectMethods{

	@Test
	public void login() {
		login(); 
	}
}









