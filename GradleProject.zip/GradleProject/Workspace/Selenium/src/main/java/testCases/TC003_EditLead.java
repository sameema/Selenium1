package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import wdmethods.ProjectMethods;

public class TC003_EditLead extends ProjectMethods
{
	
	@BeforeClass
	public void setData() {
		testcaseName ="TC003_EditLead";
		testDesc ="Edit a lead in leaftaps";
		author ="Sameema";
		category = "Smoke";
	}
	
	
/*	@BeforeMethod
	public void setUp()
	{
		login();
	}
*/	
	@AfterMethod
	public void close()
	{
		closeBrowser();
	}

	
    @Test(priority = 1)
	public void editLead()
	{
				
		WebElement eleCrmSfa = locateElement("linktext", "CRM/SFA");
		click(eleCrmSfa); 

		WebElement eleLeads = locateElement("linktext", "Leads");
		click(eleLeads);
		
		WebElement eleFindLeads = locateElement("linktext", "Find Leads");
		click(eleFindLeads);
		
		WebElement eleFirstName = locateElement("xpath", "//div[@id='center-content-column']//descendant::input[2]");
		type(eleFirstName, "Sangitha");
		
        WebElement eleFindLead = locateElement("xpath", "//div[@id='center-content-column']//descendant::button");
		click(eleFindLead); 
		
		WebElement eleFirstResultingLead = locateElement("xpath", "//div[@id='center-content-column']//following::table[3]//following::tbody/following::a");
		click(eleFirstResultingLead);
		
		String title = driver.getTitle();
		if(title.equalsIgnoreCase("view lead"))
		{
			test.info("The title is correct");
		}
		else
		{
			test.info("The title is not correct");
		}
		
		WebElement eleEdit = locateElement("xpath", "//div[@class='frameSectionHeader']//child::a[3]");
		click(eleEdit);
		
		WebElement eleCompany = locateElement("id", "updateLeadForm_companyName");
		eleCompany.clear();
		type(eleCompany, "Infosys");
		String name1 = eleCompany.getText();
		
		WebElement eleUpdate = locateElement("name", "submitButton");
        click(eleUpdate);

        WebElement eleUpdated = locateElement("id", "viewLead_companyName_sp");
        String name2 = eleUpdated.getText();
        
        if(name2.equalsIgnoreCase(name1))
        {
        	test.info("Updated company name is correct");
        }
        else
        {
        	test.info("Updated company name is not correct");
        }
        
        	}
}
