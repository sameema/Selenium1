package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import wdmethods.ProjectMethods;

public class TC004_DeleteLead extends ProjectMethods
{
	
	@BeforeClass
	public void setData() {
		testcaseName ="TC004_DeleteLead";
		testDesc ="Delete a lead from leaftaps";
		author ="Sameema";
		category = "Smoke";
	}
	
	
/*	@BeforeMethod
	public void setUp()
	{
		login();
	}
*/	
	@AfterMethod
	public void close()
	{
		closeBrowser();
	}

	
    @Test
	public void deleteLead()
	{
				
		WebElement eleCrmSfa = locateElement("linktext", "CRM/SFA");
		click(eleCrmSfa); 

		WebElement eleLeads = locateElement("linktext", "Leads");
		click(eleLeads);
		
		WebElement eleFindLeads = locateElement("linktext", "Find Leads");
		click(eleFindLeads);
		
		WebElement elePhone = locateElement("xpath", "//div[@class='allSubSectionBlocks']//following::span[4]");
		click(elePhone);
		
	}		

}

	
