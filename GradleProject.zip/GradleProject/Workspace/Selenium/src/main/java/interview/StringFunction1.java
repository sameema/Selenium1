package interview;

public class StringFunction1 {

	public static void main(String[] args) {
		String name = "abc";
		int number = name.length();
		//char[] name1 = name.toCharArray();
		for (int i = 0; i < number; i++)
		{
			String temp = name.substring(i, 1);
			System.out.print(temp);
			System.out.print(",");
		}
		
		

	}

	
}
