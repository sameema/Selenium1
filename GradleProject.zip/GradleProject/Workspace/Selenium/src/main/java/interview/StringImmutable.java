package interview;

public class StringImmutable {

	public static void main(String[] args) {
String s = "Sameema";
s = "hello";
System.out.println(s);
	}

}
