package guru99;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyLogin {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		//launch the browser
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.get("http://www.demo.guru99.com/V4/");
		WebElement userName = driver.findElementByXPath("//table/tbody/tr[1]/td[2]/input");
		userName.sendKeys("mngr171064");
		WebElement password = driver.findElementByXPath("//table/tbody/tr[2]/td[2]/input");
		password.sendKeys("uzAjaje");
		driver.findElementByXPath("//table/tbody/tr[3]/td[2]/input[1]").click();
		String title = driver.getTitle();
		System.out.println(title);
		if(title.equals("Guru99 Bank Manager HomePage"))
		{
			System.out.println("The page is verified and login is successfull");
		}

	}

}
