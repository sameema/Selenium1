package week4.day1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindow {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		driver.manage().window().maximize();	
		driver.findElementByLinkText("Contact Us").click();
		Set<String> windows = driver.getWindowHandles();
		List<String> allWindows = new ArrayList<>();
		allWindows.addAll(windows);
		driver.switchTo().window(allWindows.get(1));
		System.out.println(driver.getTitle());
		//driver.quit();
/*		driver.close();
		driver.switchTo().window(allWindows.get(0));
		driver.close();
*/
		}

}
