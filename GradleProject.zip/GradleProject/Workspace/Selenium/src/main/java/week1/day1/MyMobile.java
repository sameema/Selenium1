package week1.day1;

public class MyMobile {

	public static void main(String[] args) {
		MobilePhone mobile1 = new MobilePhone();
		long number = mobile1.doCall(9789546810l);
		String msg = mobile1.sendMsg("hello");
		String games = mobile1.playGames("chess");
		System.out.println("Contact number "+number);
		System.out.println("Message is "+msg);
		System.out.println("Number of players are "+games);
		System.out.println("Contact name is "+mobile1.contactName);
		System.out.println("The mobile type is "+mobile1.isTouch);
	

	}

}
