package week1.homework;

import java.util.Scanner;

public class Factorial {

	//to print the factorial of a number given by user
	public static void main(String[] args) {

		int n,temp=1;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value of N");
		n=scan.nextInt();
		
		System.out.println("The factorial of given number is ");
		for(int i=1;i<=n;i++)
		{
			temp=temp*i;
		}
	System.out.println(temp);
	scan.close();
	}

	}


