package week1.day1;

import java.util.Scanner;

public class Reverse {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String input = sc.next();
		int size = input.length();
		String reverse = "";
		for(int i = size-1; i>=0; i--)
		{
		reverse=reverse+input.charAt(i);
		}
		System.out.println("The reverse string is "+reverse);
		sc.close();

	}

}
