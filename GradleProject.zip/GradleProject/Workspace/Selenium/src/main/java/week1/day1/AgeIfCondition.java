package week1.day1;

import java.util.Scanner;

public class AgeIfCondition {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the age");
		int age = scan.nextInt();
		if(age>=18)
		{
			System.out.println("This person is eligble to vote");
		}
		else
		{
			System.out.println("This person is not elible to vote");
		}
		scan.close();
		

	}

}
