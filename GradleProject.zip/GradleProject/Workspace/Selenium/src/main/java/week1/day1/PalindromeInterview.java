package week1.day1;

public class PalindromeInterview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
