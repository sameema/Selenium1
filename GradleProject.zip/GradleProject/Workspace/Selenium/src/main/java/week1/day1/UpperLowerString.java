package week1.day1;

import java.util.Scanner;

public class UpperLowerString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String input = sc.next();
		int number = input.length();
		String output = "";
		char a;
		for(int i =0; i<number; i++)
		{

		if(i%2==0)
		{

		               // If it is in lower-case 

		                if (input.charAt(i) >= 'a' && input.charAt(i) <= 'z') { 

		                      // Convert into Upper-case 

		                    a = (char)(input.charAt(i) - 'a' + 'A'); 
		                     output = output+a;

		                } 
		else
		output = output+input.charAt(i);

		            } 

		              // If apart from first character 

		            // Any one is in Upper-case 

		            else
		{
		 if (input.charAt(i) >= 'A' && input.charAt(i) <= 'Z')  
		{

		  
		                // Convert into Lower-Case 

		                a = (char)(input.charAt(i) + 'a' - 'A');       
		        output = output+a;      

		        } 
		else
		output = output+input.charAt(i);

		            }

		}
		  System.out.println(output);

		sc.close();

	
}
}