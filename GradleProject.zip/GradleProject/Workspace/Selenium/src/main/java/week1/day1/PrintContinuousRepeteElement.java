package week1.day1;

import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;

public class PrintContinuousRepeteElement {

	public static void main(String[] args) {
     char[] arr = {'s','r','1','2','3','3','3','a','1','2','c','4','d','d','d','d','d','4','5','6','7','7','h','r'};
     List<Character> ls = new ArrayList<>();
     for(int i=0; i<arr.length-1;i++)
     {
    	 if(arr[i]==arr[i+1])
    	 {
    		 ls.add(arr[i]);

    	 }
     }
 
     Set<Character> st = new HashSet<>();
     st.addAll(ls);
     for(Character ch:st)
     {
    	 System.out.println("The repeated characters are :" +ch);
     }
     
     
	}

}
