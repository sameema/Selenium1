package week1.day2;

import java.util.Scanner;

public class StringFunctions2 {
//Take a name list in string array,print if it starts with 'a' or contains 'b'
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();
		String[] name = new String[size];
		for(int i=0; i<size; i++)
		{
			System.out.println("Name:"+(i+1));
			name[i]=scan.next();
		}
		System.out.println("The name is starts with either 'a' or contains 'b' are:");

		for(String each:name)
		{
			if(each.startsWith("a")||each.contains("b"))
					{
				System.out.println(each);
					}
				
			
		}
		scan.close();
		

	}

	}
