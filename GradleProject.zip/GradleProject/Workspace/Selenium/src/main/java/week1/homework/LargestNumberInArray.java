package week1.homework;

import java.util.Scanner;

public class LargestNumberInArray {

	//to find the first and 3rd largest number in the array
	public static void main(String[] args) {

		//get the array size from the user
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scan.nextInt();
		int temp;
		int numbers[] = new int[size];
		
		//get the array of numbers from user using for loop
		System.out.println("The numbers are");
		for(int i =0; i<size; i++)
		{
			numbers[i] = scan.nextInt();
		}
		
		
		
		//sort the numbers in descending order
		for(int i=0; i<size; i++)
		{
			for(int j=i+1; j<size; j++)
			{
				if(numbers[i]<numbers[j])
				{
					temp = numbers[i];
					numbers[i] = numbers[j];
					numbers[j] = temp;
				}
			}
		}
		
System.out.println("The first largest number is " +numbers[0]);
System.out.println("The first largest number is " +numbers[2]);

		scan.close();


	}

}
