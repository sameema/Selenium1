package week1.day1;

import java.util.Scanner;

public class MinMaxValue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of the array");
		int number = sc.nextInt();
		int a[] = new int[number];
		int temp;
		for(int i =0; i<number; i++)
		{
		a[i] = sc.nextInt();
		}
		for (int i= 0; i<number; i++)
		{
		for(int j = i+1; j<number; j++)
		{
		if(a[i]<a[j])
		{
		temp = a[i];
		a[i] = a[j];
		a[j] = temp;
		}
		}
		}
		System.out.println("The highest number is "+a[0]);
		System.out.println("The smallest number is "+a[number-1]);
sc.close();
	}

}
