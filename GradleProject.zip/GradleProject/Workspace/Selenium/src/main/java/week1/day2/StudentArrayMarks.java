package week1.day2;

import java.util.Scanner;

public class StudentArrayMarks {

	public static void main(String[] args) {
		//getting student array size from user
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of students");
		int number = scan.nextInt();
		
		int count = 0, temp; 
		int[] studentMarks = new int[number];
		
		//getting student marks array values from user
		for(int i=0; i<number; i++)
		{
		System.out.println("Enter the mark of student: "+(i+1));
		studentMarks[i] = scan.nextInt();
		
		//checking the codition for pass if mark greater than 50
		if(studentMarks[i]>50)
		{
		count = count+1;
		}
		}
		System.out.println("The number of pass count is " +count);
		for(int i=0; i<studentMarks.length; i++)
		{
			for(int j=i+1; j<studentMarks.length; j++)
			{
				if(studentMarks[i]>studentMarks[j])
				{
					temp = studentMarks[i];
					studentMarks[i]=studentMarks[j];
					studentMarks[j]=temp;

				}
				
			}
		}
		
		
		System.out.println("The ascending order in student marks are : ");
		for(int each:studentMarks)
		{
			System.out.println(each);
		}

		scan.close();

	}

}
