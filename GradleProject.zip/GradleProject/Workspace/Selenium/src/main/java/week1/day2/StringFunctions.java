package week1.day2;

import java.util.Scanner;

public class StringFunctions {
//to count the occurrences of 'a' in a given name. asked in most of interviews
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the name");
		String name = scan.nextLine();
		int count = 0;
		char[] list = name.toCharArray();
		for(int i=0; i<name.length(); i++)
		{
			if(list[i]=='a')
			{
				count = count +1;
			}
		}
		System.out.println("The number occurences of a in the name is "+count);
scan.close();
	}

}
