package week1.day1;

public class MobilePhone {
//methods - doCall, sendMsg, playGames
//variables- conatctNumber, contactName, noOfPlayers
	/*public void doCall()
	{
	
	}*/
	public long doCall(long contactNumber)
	{
		return contactNumber;
	}
	public String doCall(String contactName)
	{
		return contactName;
	}
	public String sendMsg(String text)
	{
		return text;
	}
	
	public String playGames(String gameName)
	{

		if(gameName.equals("chess"))
		{
			return "two";
		}
		else if(gameName.equals("carrom"))
		{
			return "four";
			}
		else
			return "single";
	}
	
	public String contactName = "Sakthi";
	boolean isTouch = true;
}
