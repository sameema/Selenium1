package week1.homework;

import java.util.Scanner;

public class PalindromeOrNot {

	//to check the given number is palindrome or not
	public static void main(String[] args) {

		int number, reverse=0,reminder;
		//get the number from the user
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		number=scan.nextInt();
		int temp=number;
		
		//reverse the given number and save it some other variable
		do
		{
			reminder=temp%10;
			reverse= reverse*10+reminder;
			temp=temp/10;
			
		}while(temp>0);
		if(number==reverse)
		System.out.println("The Given number is a palindrome");
		else
			System.out.println("The Given number is not a palindrome");
		scan.close();
		}
	

	}


