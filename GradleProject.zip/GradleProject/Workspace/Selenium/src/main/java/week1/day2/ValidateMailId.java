package week1.day2;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ValidateMailId {

	public static void main(String[] args) {
		String mail = "sameema.ranir@soprastera.com";
		String pat = "[a-zA-z][^\\w]";
		Pattern p = Pattern.compile(pat);
		Matcher m = p.matcher(mail);
		System.out.println(m.matches());
		
			}

}
