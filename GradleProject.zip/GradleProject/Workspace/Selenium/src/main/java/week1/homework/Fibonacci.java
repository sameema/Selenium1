package week1.homework;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {

		int n,a=0,b=1,temp=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value of N");
		n=scan.nextInt();
		System.out.println("The fibonacci series are ");
		if(n<=1)
		System.out.println(a+" "+b);
		else
		{
			System.out.print(a+" "+b);
		while(temp<n)
		{
			temp=a+b;
			a=b;
			b=temp;
			if(temp>n)
				break;
			else
			System.out.print(" "+temp);
			scan.close();
		}
		}
	}

	}


