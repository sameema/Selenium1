package week1.homework;

import java.util.Scanner;

public class OddOrEven {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int number = scan.nextInt();
		if(number%2==0)
		{
			System.out.println("The number "+number+" is an even number");
		}
		else
		{
			System.out.println("The number "+number+" is an odd number");

		}
		scan.close();
	}

}
