package week1.day1;

public class PrimeNumber {

	public static void main(String[] args) {
int num =22, i =2;
System.out.println("The given number is " +num);
while(i<num)
{
	if (num%i==0)
	{
		System.out.println("The given number is not a prime number");
		break;
	}
	i++;
	if(num==i)
	{
	 System.out.println("The number is a prime number");
	}
		
}

	}

}
