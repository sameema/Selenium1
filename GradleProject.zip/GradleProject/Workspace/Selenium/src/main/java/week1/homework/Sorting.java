package week1.homework;

import java.util.Scanner;

public class Sorting {

	public static void main(String[] args) {
		//program to sort in ascending and descending order - the array of numbers
		
		//get the array size from the user
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size");
		int size = scan.nextInt();
		int temp;
		int numbers[] = new int[size];
		
		//get the array of numbers from user using for loop
		System.out.println("The numbers are");
		for(int i =0; i<size; i++)
		{
			numbers[i] = scan.nextInt();
		}
		
		
		//compare the numbers in the array using 2 for loop and if condition checking for greatest number for ascending sort
		for(int i=0; i<size; i++)
		{
			for(int j=i+1; j<size; j++)
			{
				if(numbers[i]>numbers[j])
				{
					temp = numbers[i];
					numbers[i] = numbers[j];
					numbers[j] = temp;
				}
			}
		}
		System.out.println("The ascending order of the given numbers are");
		for(int each:numbers)
		{
			System.out.println(each);
		}
		

		//compare the numbers in the array using 2 for loop and if condition checking for smallest number for descending sort
		for(int i=0; i<size; i++)
		{
			for(int j=i+1; j<size; j++)
			{
				if(numbers[i]<numbers[j])
				{
					temp = numbers[i];
					numbers[i] = numbers[j];
					numbers[j] = temp;
				}
			}
		}
		System.out.println("The descending order of the given numbers are");
		for(int each:numbers)
		{
			System.out.println(each);
		}

		scan.close();

	}

}
