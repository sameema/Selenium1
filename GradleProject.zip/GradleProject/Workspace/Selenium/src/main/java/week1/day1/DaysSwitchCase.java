package week1.day1;

import java.util.Scanner;

public class DaysSwitchCase {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = scan.nextInt();
		switch(num)
		{
		case 0:
		{
			System.out.println("Today is Sunday");
			break;
		}
		case 1:
		{
			System.out.println("Today is Monday");
			break;
		}
		case 2:
		{
			System.out.println("Today is Tuesday");
			break;
		}
		case 3:
		{
			System.out.println("Today is Wednesday");
			break;
		}
		case 4:
		{
			System.out.println("Today is Thursday");
			break;
		}
		case 5:
		{
			System.out.println("Today is Friday");
			break;
		}
		case 6:
		{
			System.out.println("Today is Saturday");
			break;
		}
		}
scan.close();
	}

}
