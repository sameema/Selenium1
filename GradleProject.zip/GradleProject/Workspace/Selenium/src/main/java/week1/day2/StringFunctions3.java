package week1.day2;

import java.util.Scanner;

public class StringFunctions3 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();
		String[] name = new String[size];
		for(int i=0; i<size; i++)
		{
			System.out.println("Name:"+(i+1));
			name[i]=scan.next();
		}
			for(int i=0; i<size; i++)
			{
				
			if(int j =1; j<size; j++)
					{
				System.out.println(
					}
					
		   }
	}

}
