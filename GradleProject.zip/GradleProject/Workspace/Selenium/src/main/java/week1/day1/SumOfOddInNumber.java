package week1.day1;

import java.util.Scanner;

public class SumOfOddInNumber {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the numebr");
		int num = scan.nextInt();
	    int sum=0, j;
	    while(num%10 != 0)
	    	{
	    	j = num%10;
	    	if(j%2!=0)
	    	{
	  	    sum = sum + j;
	    	}
	    	num = num/10;
	    	}
	    System.out.println("The sum of odd numbers in the given number is "+sum);
scan.close();
	}

}
