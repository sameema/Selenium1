package week1.day2;

public class test1 {
        
        
        public static void main(String[] args){               
               
               int i = 49;
 
               if(i > 50) {
                       System.out.println("Greater than 50");
                       System.out.println("Greater ");
               }
               else
               {
                       System.out.println("Less than 50");
               }
        
        }
}
