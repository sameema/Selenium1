package week1.homework;

import java.util.Scanner;

public class GreatestNumberIfCondition {
//program to find the greatest number among 3 numbers
	public static void main(String[] args) {

		//get 3 numbers from user using the Scanner class
		Scanner scan1 = new Scanner(System.in);
		System.out.println("Enter the three numbers");
		int num1 = scan1.nextInt();
		int num2 = scan1.nextInt();
		int num3 = scan1.nextInt();
		
		//checking whether num1 is greater than num2 and num3 using if statement
		if(num1>num2 && num1>num3)
		{
			System.out.println(num1+" is the greatest number");
		}
		
		//if the num1 is not greater than num2 and num3, then check num2 is greater than num3
		else if(num2>num3)
		{
			System.out.println(num2+" is the greatest number");
		}
		
		//if both num1 and num2 are not the greatest number, then print print num3 is the greatest
		else
			System.out.println(num3+" is the greatest number");
		scan1.close();
	}

}
