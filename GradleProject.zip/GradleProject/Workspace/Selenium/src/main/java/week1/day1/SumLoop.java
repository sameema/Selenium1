package week1.day1;

import java.util.Scanner;

public class SumLoop {

	public static void main(String[] args) {
		int sum = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = scan.nextInt();
		for(int i=0;i<=num;i++)
		{
			sum = sum + i;
		}
System.out.println("The sum of "+num+" numbers are " +sum);
scan.close();
	}

}
