package week5.day1;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class HtmlReport {
	@Test
	public void reports() throws IOException
	{
		ExtentHtmlReporter html = new ExtentHtmlReporter("./Reports/result.html");
		html.setAppendExisting(true);
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(html);
		ExtentTest test = extent.createTest("CreateLead", "Create a new lead in leaftaps");
		test.assignAuthor("Sameema");
		test.assignCategory("Smoke Test");
		test.pass("Step 1: passed", MediaEntityBuilder.createScreenCaptureFromPath("./../snaps/img.png").build());
		test.pass("Step 2: passed", MediaEntityBuilder.createScreenCaptureFromPath("./../snaps/img.png").build());
		test.pass("Step 3: passed", MediaEntityBuilder.createScreenCaptureFromPath("./../snaps/img.png").build());
		test.pass("Step 4: passed", MediaEntityBuilder.createScreenCaptureFromPath("./../snaps/img.png").build());
		extent.flush();
	
	}

}
