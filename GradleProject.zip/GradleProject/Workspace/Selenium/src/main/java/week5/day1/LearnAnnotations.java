package week5.day1;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LearnAnnotations {
	
	@BeforeSuite
	public void wakeUp()
	{
		System.out.println("Wake Up");
	}

	@BeforeTest
	public void brush()
	{
		System.out.println("Brush");
	}
	
	@BeforeClass
	public void getReady()
	{
		System.out.println("Getting Ready");
	}
	
	@BeforeMethod
	public void goToOffice()
	{
		System.out.println("Going to office");
	}
	
	@Test
	public void UC001_doTask()
	{
		System.out.println("Doing Task");
	}
	
	@Test
	public void UC002_breakTime()
	{
		System.out.println("Take a break");
	}
	
	@Test
	public void UC003_lunchTime()
	{
		System.out.println("Lunch Time");
	}
	
	@AfterMethod
	public void goHome()
	{
		System.out.println("Going Home");
	}
	
	@AfterClass
	public void dressChange()
	{
		System.out.println("Casual wear");
	}
	
	@AfterTest
	public void brushBeforeBed()
	{
		System.out.println("brush before bed");
	}
	
	@AfterSuite
	public void goToSleep()
	{
		System.out.println("Go to sleep");
	}
}
